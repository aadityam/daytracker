//
//  Country.swift
//  DayTracker
//
//  Created by ITP on 10/25/16.
//  Copyright © 2016 usc. All rights reserved.
//

import UIKit

class Country {
    // MARK: Properties
    
    var name: String
    var daysLeft: Int
    var daysSpent: Int
    
    // MARK: Initialization
    
    init?(name: String, daysLeft: Int, daysSpent: Int) {
        // Initialize stored properties.
        self.name = name
        self.daysLeft = daysLeft
        self.daysSpent = daysSpent
        
        // Initialization should fail if there is no name or if the rating is negative.
//        if name.isEmpty || rating < 0 {
//            return nil
//        }
    }
    
}