//
//  HomeTableViewController.swift
//  DayTracker
//
//  Created by ITP on 10/25/16.
//  Copyright © 2016 usc. All rights reserved.
//

import UIKit

class HomeTableViewController: UITableViewController {
    var countries = [Country]()
    var selectedCountry: Country?
    override func viewDidLoad() {
        super.viewDidLoad()
        loadSampleCountries()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    func loadSampleCountries() {
        let country1 = Country(name: "United States of America", daysLeft: 45, daysSpent: 135)!
        let country2 = Country(name: "Canada", daysLeft: 120, daysSpent: 60)!
        let country3 = Country(name: "India", daysLeft: 170, daysSpent: 10)!
        
        countries += [country1, country2, country3]
    }

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return countries.count
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("HomeCell", forIndexPath: indexPath) as! HomeTableViewCell
        
        // Fetches the appropriate meal for the data source layout.
        let country = countries[indexPath.row]
        let daysSpentString = String(country.daysSpent)
        let totalDaysString = String(country.daysSpent + country.daysLeft)
        cell.countryLabel.text = country.name + " : " + daysSpentString + "/" + totalDaysString
        
        
        return cell
    }
    
    @IBAction func unwindToCountryList(sender: UIStoryboardSegue) {
        if let sourceViewController = sender.sourceViewController as? SearchTableViewController,
            country = sourceViewController.countrySelect {
            countries += [country]
        }
        self.tableView.reloadData()
    }
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        //selectedCountry = countries[indexPath.row]
        self.performSegueWithIdentifier("detailViewSegue", sender: indexPath);
        
    }

//    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
//        if (segue.identifier == "detailViewSegue") {
//            let cell = self.tableView.dequeueReusableCellWithIdentifier("HomeCell") as! HomeTableViewCell
//            let controller = segue.destinationViewController as! DetailViewController
//            let row = (sender as! NSIndexPath).row;
//            selectedCountry = countries[row]
//            controller.countryLabel.text = selectedCountry?.name
//        }
//        
//    }
 

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
}