//
//  HomeTableViewCell.swift
//  DayTracker
//
//  Created by ITP on 10/25/16.
//  Copyright © 2016 usc. All rights reserved.
//

import UIKit

class HomeTableViewCell: UITableViewCell {

    @IBOutlet weak var countryLabel: UILabel!
}

class SearchTableViewCell: UITableViewCell {
    
    @IBOutlet weak var searchCountryLabel: UILabel!
    
}
