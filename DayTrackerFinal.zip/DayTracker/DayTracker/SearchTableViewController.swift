//
//  SearchTableViewController.swift
//  DayTracker
//
//  Created by ITP on 11/16/16.
//  Copyright © 2016 usc. All rights reserved.
//

import UIKit

class SearchTableViewController: UITableViewController, UISearchBarDelegate {
    @IBOutlet weak var countrySearchBar: UISearchBar!
    var countrySelect: Country!
    var countriesArray = [Country]()
    var filteredArray = [Country]()
    var searchActive : Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        countrySearchBar.delegate = self

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        countriesArray = [
            Country(name:"China", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Japan", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Australia", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Egypt", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Nigeria", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Malaysia", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Congo", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Russia", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Germany", daysLeft: 90, daysSpent: 90)!,
            Country(name:"France", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Spain", daysLeft: 90, daysSpent: 90)!,
            Country(name:"England", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Italy", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Brazil", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Mexico", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Argentina", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Chile", daysLeft: 90, daysSpent: 90)!,
            Country(name:"United Arab Emirates", daysLeft: 90, daysSpent: 90)!,
            Country(name:"Peru", daysLeft: 90, daysSpent: 90)!,
            Country(name:"South Korea", daysLeft: 90, daysSpent: 90)!
            ]
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
        searchActive = true;
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchActive = false;
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        searchActive = false;
    }


    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        
        filteredArray = countriesArray.filter({ (text) -> Bool in
            let tmp: NSString = text.name
            let range = tmp.rangeOfString(searchText, options: NSStringCompareOptions.CaseInsensitiveSearch)
            return range.location != NSNotFound
        })
        if(filteredArray.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        self.tableView.reloadData()
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if(searchActive) {
            return filteredArray.count
        }
        return countriesArray.count;    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("SearchCell", forIndexPath: indexPath) as! SearchTableViewCell
        if(searchActive){
            cell.searchCountryLabel.text = filteredArray[indexPath.row].name
        } else {
            cell.searchCountryLabel.text = countriesArray[indexPath.row].name
        }
        
        return cell;
    }
    

    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        //let cell = tableView.cellForRowAtIndexPath(indexPath)
        if(searchActive)
        {
            countrySelect = filteredArray[indexPath.row]
        } else{
            countrySelect = countriesArray[indexPath.row]
        }
        
        performSegueWithIdentifier("unwindToCountryListSegue", sender: self)
}

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


}